## Ce qui change

- ajoute l’architecture modulaire `kingdomCore`, `KingdomVoice`, `KingdomData`, `kingdomEvent` et `KingdomWeb` ;
- fournit un Studio no-code pour les bâtiments, objets, événements, bots et contenus audio ;
- importe les 48 objets et les cinq profils vocaux de KingdomEngine V1 ;
- ajoute le runtime Discord dynamique et la supervision multi-bots vocaux ;
- ajoute l’installateur Windows et le provisionnement idempotent des rôles et salons Discord ;
- documente l’installation, le lancement et le déploiement sur un serveur test.

## Pourquoi

Transformer KingdomEngine en moteur de jeu no-code piloté depuis le Web, tout en séparant clairement les données, le métier, les événements, Discord et la voix.

## Impact

Les contenus publiés dans KingdomWeb sont consommés directement par les runtimes Discord. Les secrets restent dans `.env`, qui est exclu du dépôt.

## Validation

- recherche locale de secrets : aucun résultat ;
- `python -m pytest -q` : 12 tests réussis ;
- validation syntaxique JavaScript et PowerShell effectuée localement.
