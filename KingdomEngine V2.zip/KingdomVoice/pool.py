"""Pool générique de ressources Discord vocales.

Ce module ne dépend pas de discord.py afin que l'allocation, les quotas et la
libération restent testables sans connexion réelle. Le bot manager constitue
l'adaptateur Discord et applique ensuite le résultat de l'allocation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from threading import RLock
from typing import Any


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(slots=True)
class VoiceProfile:
    key: str
    provider: str = "files"
    language: str = ""
    volume: float = 1.0
    categories: dict[str, list[str]] = field(default_factory=dict)
    fallback_profile_key: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class VoicePresence:
    key: str
    name: str
    presence_type: str = "custom"
    source_key: str = ""
    avatar_url: str = ""
    voice_profile_key: str = ""
    scene_key: str = ""
    priority: int = 0
    location_key: str = ""
    assignment_mode: str = "on_demand"
    release_timeout_seconds: int = 30
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.presence_type not in {"npc", "ambience", "custom"}:
            raise ValueError("Type de présence vocale invalide.")


@dataclass(slots=True)
class VoiceWorkerState:
    key: str
    guild_id: str = ""
    state: str = "free"
    channel_id: str = ""
    presence_key: str = ""
    scene_key: str = ""
    last_activity: str = field(default_factory=_now)
    error: str = ""

    @property
    def free(self) -> bool:
        return self.state == "free" and not self.presence_key


class VoiceWorkerPool:
    """Alloue au plus ``max_concurrent_voice_presences`` workers à la fois."""

    def __init__(self, workers: list[VoiceWorkerState] | None = None, *, max_concurrent_voice_presences: int | None = None) -> None:
        self.workers = {worker.key: worker for worker in (workers or [])}
        self._lock = RLock()
        self._allocation_cursor = 0
        physical_capacity = len(self.workers)
        requested = physical_capacity if max_concurrent_voice_presences is None else max(0, int(max_concurrent_voice_presences))
        self.max_concurrent_voice_presences = min(physical_capacity, requested)

    def register(self, worker: VoiceWorkerState) -> None:
        with self._lock:
            self.workers[worker.key] = worker
            if self.max_concurrent_voice_presences == 0:
                self.max_concurrent_voice_presences = len(self.workers)

    def allocate(
        self,
        presence: VoicePresence,
        *,
        guild_id: str = "",
        channel_id: str = "",
        eligible_worker_keys: set[str] | None = None,
    ) -> VoiceWorkerState | None:
        with self._lock:
            eligible = lambda worker: eligible_worker_keys is None or worker.key in eligible_worker_keys
            stale = next(
                (
                    worker
                    for worker in self.workers.values()
                    if worker.presence_key == presence.key and not eligible(worker)
                ),
                None,
            )
            if stale:
                # Seul le gestionnaire peut confirmer la déconnexion physique.
                # Garder la réservation empêche un second bot de l'incarner.
                return None
            existing = next((worker for worker in self.workers.values() if worker.presence_key == presence.key and eligible(worker)), None)
            if existing:
                existing.guild_id = guild_id or existing.guild_id; existing.channel_id = channel_id or existing.channel_id; existing.last_activity = _now()
                return existing
            active = sum(not worker.free for worker in self.workers.values())
            if active >= self.max_concurrent_voice_presences:
                return None
            ordered = list(self.workers.values())
            worker = None
            if ordered:
                for offset in range(len(ordered)):
                    index = (self._allocation_cursor + offset) % len(ordered)
                    candidate = ordered[index]
                    if candidate.free and eligible(candidate):
                        worker = candidate
                        self._allocation_cursor = (index + 1) % len(ordered)
                        break
            if worker is None:
                return None
            worker.state = "assigned"; worker.presence_key = presence.key; worker.guild_id = guild_id
            worker.channel_id = channel_id; worker.scene_key = presence.scene_key; worker.last_activity = _now(); worker.error = ""
            return worker

    def release(self, *, presence_key: str = "", worker_key: str = "") -> VoiceWorkerState | None:
        with self._lock:
            worker = self.workers.get(worker_key) if worker_key else next((item for item in self.workers.values() if item.presence_key == presence_key), None)
            if not worker: return None
            worker.state = "free"; worker.channel_id = ""; worker.presence_key = ""; worker.scene_key = ""; worker.last_activity = _now(); worker.error = ""
            return worker

    def touch(self, worker_key: str) -> VoiceWorkerState:
        """Signale qu'un worker est toujours utilisé dans son salon vocal."""
        with self._lock:
            worker = self.workers[worker_key]
            worker.last_activity = _now()
            return worker

    def fail(self, worker_key: str, error: Exception | str) -> None:
        with self._lock:
            worker = self.workers[worker_key]; worker.state = "error"; worker.error = str(error)[:500]; worker.last_activity = _now()

    def recover(self, worker_key: str) -> VoiceWorkerState:
        """Rend un worker de nouveau allouable après reconnexion du client Discord."""
        worker = self.release(worker_key=worker_key)
        if worker is None: raise KeyError(worker_key)
        return worker

    def sweep(self, presences: dict[str, VoicePresence], *, now: datetime | None = None) -> list[str]:
        """Libère les présences supprimées ou inactives, sans interrompre le gameplay."""
        reference = now or datetime.now(timezone.utc); released: list[str] = []
        with self._lock:
            for worker in self.workers.values():
                presence = presences.get(worker.presence_key)
                if worker.free: continue
                if presence is None:
                    released.append(worker.key); self.release(worker_key=worker.key); continue
                last = datetime.fromisoformat(worker.last_activity)
                if presence.release_timeout_seconds and (reference - last).total_seconds() >= presence.release_timeout_seconds:
                    released.append(worker.key); self.release(worker_key=worker.key)
        return released

    def snapshot(self) -> dict[str, Any]:
        active = sum(not worker.free for worker in self.workers.values())
        return {"capacity": len(self.workers), "quota": self.max_concurrent_voice_presences, "active": active, "available": max(0, self.max_concurrent_voice_presences - active), "workers": [
            {"key": worker.key, "state": worker.state, "guild_id": worker.guild_id, "channel_id": worker.channel_id, "presence_key": worker.presence_key, "scene_key": worker.scene_key, "last_activity": worker.last_activity, "error": worker.error}
            for worker in self.workers.values()
        ]}
